using Assets.PixelFantasy.Common.Scripts;

namespace Assets.PixelFantasy.PixelMonsters.Common.Scripts
{
    /// <summary>
    /// The main monster script.
    /// </summary>
    public class Monster : Creature
    {
    }
}