using System.Linq;
using UnityEngine;

namespace Assets.PixelFantasy.PixelMonsters.Common.Scripts.ExampleScripts
{
    [RequireComponent(typeof(Collider2D))]
    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(MonsterAnimation))]
    public class MonsterController2D : MonoBehaviour
    {
        public Vector2 Input;
        public bool IsGrounded;

        public float Acceleration = 40;
        public float MaxSpeed = 8;
        public float JumpForce = 1000;
        public float Gravity = 70;

        private Collider2D _collider;
        private Rigidbody2D _rigidbody;
        private MonsterAnimation _animation;

        private bool _jump;
        public float localGravity = 9.8f; // Constant gravity towards planet's center

        public Transform GroundCheck;
        public LayerMask whatIsGround;

        public Transform PlanetCenter; // Reference to the planet's center

        public void Start()
        {
            _collider = GetComponent<Collider2D>();
            _rigidbody = GetComponent<Rigidbody2D>();
            _animation = GetComponent<MonsterAnimation>();

            _rigidbody.gravityScale = 0; // Disable default gravity
            _rigidbody.freezeRotation = true; // Prevent rotation
        }

        public void Update()
        {
            IsGrounded = Physics2D.OverlapCircle(GroundCheck.position, 0.2f, whatIsGround);

            // Check animation states as needed
        }

        public void FixedUpdate()
        {
            var state = _animation.GetState();

            if (state == MonsterState.Die) return;

            var velocity = _rigidbody.velocity;

            // Simplify horizontal movement control
            if (Input.x != 0)
            {
                velocity.x = Mathf.MoveTowards(velocity.x, Input.x * MaxSpeed, Acceleration * Time.fixedDeltaTime);
            }

            // Apply force towards the planet center to simulate gravity
            ApplyGravity();

            // Update velocity
            _rigidbody.velocity = velocity;
        }

        private void ApplyGravity()
        {
            Vector3 gravityDirection = (PlanetCenter.position - transform.position).normalized;
            _rigidbody.AddForce(gravityDirection * localGravity * _rigidbody.mass);
            
            // Align the pig's rotation towards the planet
            AlignToPlanet(gravityDirection);
        }

        private void AlignToPlanet(Vector3 gravityDirection)
        {
            Quaternion targetRotation = Quaternion.FromToRotation(transform.up, -gravityDirection);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, 10 * Time.fixedDeltaTime);
        }

        private void Turn(float direction)
        {
            var scale = transform.localScale;
            scale.x = Mathf.Sign(direction) * Mathf.Abs(scale.x);
            transform.localScale = scale;
        }

        public void OnCollisionEnter2D(Collision2D collision)
        {
            if (collision.contacts.Any(contact => contact.point.y <= _collider.bounds.min.y + 0.1f))
            {
                IsGrounded = true;

                if (_jump)
                {
                    _jump = false;
                    _animation.Land();
                }
            }
        }

        public void OnCollisionExit2D(Collision2D collision)
        {
            if (IsGrounded && collision.collider == _collider)
            {
                IsGrounded = false;
            }
        }
    }
}
